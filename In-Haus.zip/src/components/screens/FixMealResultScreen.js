import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';

export default function FixMealResultScreen({ route, navigation }) {
  const { apiResponse } = route.params;

  return (
    <ScrollView style={styles.resultContainer}>
      <Text style={styles.resultTitle}>Meal Fixing Result</Text>

      {/* Display meal ingredients */}
      <Text style={styles.resultText}>Ingredients recognized:</Text>
      {apiResponse.ingredientsRecognized.map((ingredient, index) => (
        <Text key={index} style={styles.resultText}>- {ingredient.name}</Text>
      ))}

      {/* Display meal suggestions */}
      <Text style={styles.resultText}>Meal Suggestions:</Text>
      {apiResponse.mealSuggestions.map((meal, index) => (
        <View key={index}>
          <Text style={styles.resultText}>Meal Name: {meal.mealName}</Text>
          <Text style={styles.resultText}>Recipe: {meal.recipe}</Text>
          <Text style={styles.resultText}>Ingredients:</Text>
          {meal.ingredients.map((ingredient, i) => (
            <Text key={i} style={styles.resultText}>- {ingredient.qty} {ingredient.name} ({ingredient.note})</Text>
          ))}
        </View>
      ))}

      {/* Button to go back */}
      <TouchableOpacity style={styles.button} onPress={() => navigation.popToTop()}>
        <Text style={styles.label}>Back to MealAI Menu</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  resultContainer: {
    flex: 1,
    padding: 20,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  resultText: {
    fontSize: 16,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#f0f0f0',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  label: {
    fontSize: 16,
    color: 'black',
  },
});
