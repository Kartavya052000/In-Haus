import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, Dimensions, Platform, StatusBar } from 'react-native';
import Typography from '../../components/typography/Typography'; // Import Typography
import FontAwesome6 from '@expo/vector-icons/FontAwesome6'; // Import FontAwesome for icons
import Checkbox from '../../components/Selectors/Checkbox/Checkbox';
import RangeSlider from '../../components/sliders/Slider'; // Assuming you have a RangeSlider component
import CustomLoadingScreen from '../../components/Loading/CustomLoadingScreen'; // Import Custom Loading Screen
import { useNavigation, useRoute } from '@react-navigation/native';

const SearchMeal = () => {
  const navigation = useNavigation();
  const route = useRoute();

  // Destructure with fallback defaults
  const {
    selectedMealType = 'General',
    initialCuisines = ['Chinese', 'Indian', 'Japanese', 'Latin America', 'Italian', 'Vietnamese'],
    initialMealStyles = ['Main', 'Dessert', 'Breakfast', 'Side', 'Salad', 'Soup']
  } = route.params || {};

  // Ensure state is never undefined
  const [mealStyles, setMealStyles] = React.useState(initialMealStyles);
  const [cuisines, setCuisines] = React.useState(initialCuisines);
  const [loading, setLoading] = React.useState(false);
  const [servings, setServings] = React.useState(1);
  const [isMealStyleOpen, setIsMealStyleOpen] = React.useState(false);
  const [isCuisinesOpen, setIsCuisinesOpen] = React.useState(false);

  // Debug logging to ensure correct data
  console.log('Meal Styles:', mealStyles);
  console.log('Cuisines:', cuisines);

  const handleBack = () => {
    navigation.goBack();
  };

  const handleCameraPress = () => {
    navigation.navigate('CameraScreen'); // Navigate to CameraScreen.js
  };

  const handleSearch = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigation.navigate('SearchResults'); // Navigate to SearchResults.js
    }, 1000); // Simulate loading
  };

  const toggleMealStyle = () => {
    setIsMealStyleOpen(!isMealStyleOpen);
  };

  const toggleCuisines = () => {
    setIsCuisinesOpen(!isCuisinesOpen);
  };

  return (
    <View style={styles.container}>
      {loading && <CustomLoadingScreen />}

      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={handleBack}>
          <FontAwesome6 name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Typography variant="H4" style={styles.headerTitle}>MealAI</Typography>
        <TouchableOpacity onPress={handleCameraPress}>
          <FontAwesome6 name="camera" size={24} color="#6b52ae" style={styles.cameraIcon} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <FontAwesome6 name="search" size={20} color="#999" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search specific meal"
          />
        </View>
      </View>

      <ScrollView style={styles.scrollContainer} contentContainerStyle={{ paddingBottom: 24 }}>
        {/* Meal Style Section */}
        <TouchableOpacity onPress={toggleMealStyle} style={styles.accordionHeader}>
          <Typography variant="SH4" style={styles.accordionTitle}>Meal Style</Typography>
          <FontAwesome6 name={isMealStyleOpen ? "chevron-up" : "chevron-down"} size={16} color="#333" />
        </TouchableOpacity>
        {isMealStyleOpen && Array.isArray(mealStyles) && mealStyles.length > 0 && (
          <View style={styles.buttonGroup}>
            {mealStyles.map((mealType, index) => (
              <TouchableOpacity key={index} style={styles.optionButton}>
                <FontAwesome6 name="utensils" size={16} color="#6b52ae" style={styles.optionIcon} />
                <Text style={styles.optionText}>{mealType}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Select Cuisines Section */}
        <TouchableOpacity onPress={toggleCuisines} style={styles.accordionHeader}>
          <Typography variant="SH4" style={styles.accordionTitle}>Select cuisines (Max 5 cuisines)</Typography>
          <FontAwesome6 name={isCuisinesOpen ? "chevron-up" : "chevron-down"} size={16} color="#333" />
        </TouchableOpacity>
        {isCuisinesOpen && Array.isArray(cuisines) && cuisines.length > 0 && (
          <View style={styles.buttonGroup}>
            {cuisines.map((cuisine, index) => (
              <TouchableOpacity key={index} style={styles.optionButton}>
                <FontAwesome6 name="globe" size={16} color="#6b52ae" style={styles.optionIcon} />
                <Text style={styles.optionText}>{cuisine}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Amount of Servings Section */}
        <View style={styles.servingsSection}>
          <Typography variant="SH4" style={styles.servingsTitle}>Amount of Servings</Typography>
          <RangeSlider
            minimumValue={1}
            maximumValue={10}
            step={1}
            value={servings}
            onValueChange={value => setServings(value)}
          />
        </View>

        <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
          <Text style={styles.searchButtonText}>Search</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 24,
    backgroundColor: '#fff',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 60, // Add padding to avoid the notch or island
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    marginTop: 16,
  },
  headerTitle: {
    fontWeight: 'bold',
  },
  addMealButton: {
    position: 'absolute',
    right: 0,
    padding: 8,
  },
  addMealContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: -2, // Adjust alignment to match the text and icon height
  },
  addMealText: {
    lineHeight: 17, // Align the text vertically with the icon
  },
  addIcon: {
    marginBottom: -2, // Adjust icon alignment to match the text height
  },
  calendarSection: {
    marginBottom: 24,
    paddingHorizontal: 0,
  },
  mealSection: {
    marginBottom: 16,
  },
  mealTitle: {
    marginBottom: 8,
    fontWeight: 'bold',
  },
  mealCardsContainer: {
    flex: 1,
  },
  mealCard: {
    marginBottom: 16, // Space between cards
    backgroundColor: '#f9f9f9', // Set default background color for MealCard
    borderRadius: 12, // Add rounded corners
    padding: 0, // Add padding inside the card
  },
  addMealContentCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noMealText: {
    textAlign: 'center',
    color: '#999',
  },
  shoppingListSection: {
    marginTop: 24,
    paddingHorizontal: 16,
  },
  filterSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  filterTitle: {
    fontWeight: 'bold',
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  filterText: {
    marginRight: 4,
  },
  shoppingListItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  itemName: {
    fontWeight: 'bold',
  },
  itemQuantity: {
    color: '#999',
  },
});

export default SearchMeal;
