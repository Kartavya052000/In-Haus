export const GRAPHQL_ENDPOINT = 'http://localhost:4000/graphql';
